# vulnerable.py
# Código intencionalmente vulnerable
def main():
    user_input = input("Enter a command: ")
    print(eval(user_input))  # Vulnerabilidad: ejecución de código arbitrario

if _name_ == "_main_":
    main()
